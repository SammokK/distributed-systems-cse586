package edu.buffalo.cse.cse486586.groupmessenger2;

/**
 * Created by SammokKabasi on 3/15/16.
 */
public class Constants {
    public static final String KEY = "key";
    public static final String VALUE = "value";
    public static final String GROUP_MESSENGER = "GROUP_MESSENGER";

}
